// 生产环境配置
// 这个文件会在运行时被加载
window.__APP_CONFIG__ = {
  API_BASE_URL: 'http://182.92.59.70:3002'
}
